#!/bin/bash

echo -n "Hello World!"

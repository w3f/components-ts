#!/bin/sh

echo -n "Hello World!"
